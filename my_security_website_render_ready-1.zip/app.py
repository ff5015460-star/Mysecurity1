from flask import Flask, render_template, request, redirect, session

app = Flask(__name__)
app.secret_key = "my-security-change-this-secret-key"

DEMO_USER = "radha"
DEMO_PASSWORD = "143"

@app.route("/")
def home():
    return render_template("index.html", logged_in=("user" in session))

@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        if username == DEMO_USER and password == DEMO_PASSWORD:
            session["user"] = username
            return redirect("/dashboard")
        error = "Invalid username or password."
    return render_template("login.html", error=error)

@app.route("/signup")
def signup():
    return render_template("signup.html")

@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect("/login")
    return render_template("dashboard.html", username=session["user"])

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
